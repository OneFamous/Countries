package com.fatihates.countries.model

data class Country (val countryName: String?){
}