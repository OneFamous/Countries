package com.fatihates.countries.viewmodel

import androidx.lifecycle.ViewModel

class ListViewModel: ViewModel(){

}